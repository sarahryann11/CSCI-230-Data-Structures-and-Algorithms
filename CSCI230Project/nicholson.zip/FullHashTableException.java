package csci230project;

/**
 *
 * @author Sarah Nicholson
 */
public class FullHashTableException extends Exception
{
    public FullHashTableException()
    {
        super("hash table is full");
    }
}
