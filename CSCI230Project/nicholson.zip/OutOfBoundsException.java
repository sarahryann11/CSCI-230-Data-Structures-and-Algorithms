package csci230project;

/**
 *
 * @author Sarah Nicholson
 */
class OutOfBoundsException extends Exception {
    
}
