package csci230.hwk7;

public class HeapTest {

	public static void main(String[] args) {
		
		ArrayList<Integer> list = new ArrayList<Integer>();
		ArrayList<Integer> sorted_list = new ArrayList<Integer>();
		
		list.add( 5 );
		list.add( 16 );
		list.add( 8 );
		list.add( 14 );
		list.add( 20 );
		list.add( 1 );
		list.add( 26 );
		
		Utils.heapSort( sorted_list, list, true );
		System.out.println ( sorted_list );
		
		SinglyLinkedList<Integer> slist = new SinglyLinkedList<Integer>();
		SinglyLinkedList<Integer> sorted_slist = new SinglyLinkedList<Integer>();
		
		slist.add( 5 );
		slist.add( 16 );
		slist.add( 8 );
		slist.add( 14 );
		slist.add( 20 );
		slist.add( 1 );
		slist.add( 26 );
		
		Utils.heapSort(sorted_slist, slist, true );
		System.out.println( sorted_slist );

	}

}
